def insertar_la_k_multiplos(lista_2, k):
    resultado= []
    for numero in lista_2:
        resultado.append(numero)
        if numero % k == 0:  
            resultado.append(k)
    return resultado

h=int(input("Ingrese la cantidad de números en la lista: "))

lista_2= []
for _ in range(h):
    numero=int(input("Ingrese un número entero: "))
    lista_2.append(numero)

variable_k=int(input("Ingrese el número entero K: "))

lista_modificada_2= insertar_la_k_multiplos(lista_2, variable_k)

print("\nLista original:", lista_2)
print("Lista modificada:", lista_modificada_2)

M = int(input("Ingrese la cantidad de filas: "))
N = int(input("Ingrese la cantidad de columnas: "))

matriz = []
for i in range(M):
    fila = []
    for j in range(N):
        num = float(input(f"Ingrese el valor para la posición [{i+1},{j+1}]: "))
        fila.append(num)
    matriz.append(fila)

print("Matriz ingresada:")
for fila in matriz:
    print(fila)

k = int(input("Ingrese la fila del elemento: ")) - 1  
h = int(input("Ingrese la columna del elemento: ")) - 1
elemento = matriz[k][h]
es_maximo_en_fila = elemento == max(matriz[k])

columna_h = [matriz[i][h] for i in range(M)]  
es_minimo_en_columna = elemento == min(columna_h)

if es_maximo_en_fila and es_minimo_en_columna:
    print(f"El elemento A[{k+1},{h+1}] = {elemento} si es un punto silla. ")
else:
    print(f"El elemento A[{k+1},{h+1}] = {elemento} no es un punto silla. ")

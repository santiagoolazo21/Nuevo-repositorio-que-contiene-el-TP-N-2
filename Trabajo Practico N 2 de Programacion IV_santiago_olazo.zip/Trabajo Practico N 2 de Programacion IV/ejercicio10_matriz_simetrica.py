def es_simetrica(matriz):
    filas = len(matriz)
    columnas = len(matriz[0])
    
    if filas != columnas:
        return False 
    
    for i in range(filas):
        for j in range(i+1, columnas): 
            if matriz[i][j] != matriz[j][i]:
                return False
    return True

def procesar_matriz(N, M):
    matriz = []
    for i in range(N):
        fila = list(map(int, input(f"Ingrese los elementos de la fila {i+1}: ").split()))
        matriz.append(fila)

    if es_simetrica(matriz):
        print("La matriz es simétrica.")
    else:
        print("La matriz no es simétrica.")

N = int(input("Ingrese el número de filas de la matriz: "))
M = int(input("Ingrese el número de columnas de la matriz: "))
procesar_matriz(N, M)

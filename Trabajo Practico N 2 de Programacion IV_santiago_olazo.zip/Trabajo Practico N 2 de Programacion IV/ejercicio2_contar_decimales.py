def converir_numeros():
    numeros_decimales= input("Ingrese un número decimal: ")
    eliminar_signo= numeros_decimales.lstrip('-')  
    if '.' in eliminar_signo:
        parte_entera= eliminar_signo.split('.')
        parte_decimal= eliminar_signo.split('.')
    else:
        parte_entera= eliminar_signo
        parte_decimal= ''
    digitos_enteros= len(parte_entera)
    digitos_decimales= len(parte_decimal)
    print(f"La cantidad de dígitos enteros son: {digitos_enteros}")
    print(f"La cantidad de dígitos decimales son: {digitos_decimales}")
converir_numeros()
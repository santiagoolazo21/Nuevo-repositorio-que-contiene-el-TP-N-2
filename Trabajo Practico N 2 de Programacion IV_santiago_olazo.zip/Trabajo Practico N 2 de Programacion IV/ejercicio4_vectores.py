numeros= int(input("Ingrese la cantidad de dígitos que deseia ingresar: "))
lista_vector= []

for a in range(numeros):
    num = int(input(f"Ingrese el dígito {a+1}: "))  
    lista_vector.append(num)

vector_auxiliar= []
for a in range(numeros - 1, -1, -1):  
    vector_auxiliar.append(lista_vector[a])

vector_no_auxiliar= lista_vector[:] 
principio= 0
final= numeros - 1

while principio < final:  
    vector_no_auxiliar[principio], vector_no_auxiliar[final] = vector_no_auxiliar[final], vector_no_auxiliar[principio]
    principio += 1
    final -= 1
print("El vector original es:", lista_vector)
print("El vector invertido, usando auxiliares es:", vector_auxiliar)
print("El vector invertido, sin auxiliares:", vector_no_auxiliar)

def contar_pares_e_impares(numero):
    parte_entera = abs(int(numero)) 
    pares_numeros= 0
    impares_numeros= 0

    while parte_entera > 0:
        digito = parte_entera % 10  
        if digito % 2 == 0:
            pares_numeros += 1  
        else:
            impares_numeros += 1   
        parte_entera //= 10  

    return pares_numeros, impares_numeros  
entrada_numeros = int(input("Ingrese la cantidad de números en la lista A: "))

lista_a = []
for _ in range(entrada_numeros):
    numeros_reales = float(input("Ingrese un número real: "))
    lista_a.append(numeros_reales)

lista_b = []
for numeros_reales in lista_a:
    pares_numeros, impares_numeros = contar_pares_e_impares(numeros_reales)
    if pares_numeros == 2 or impares_numeros >= 2:
        lista_b.append(numeros_reales)

print("La lista A original es:", lista_a)
print("La lista B, que es filtrada presenta:", lista_b if lista_b else "No hay elementos que cumplan los requisitos.")

def existe_compuesto(entrada):
    if abs(entrada) < 2:  
        return False
    divisores_numeros= 0
    for i in range(1, abs(entrada) + 1):  
        if abs(entrada) % i == 0:
            divisores_numeros += 1
    return divisores_numeros > 2
cantidad_numeros=int(input("Ingrese la cantidad de números en el vector: "))

vector_lista= []
for _ in range(cantidad_numeros):
    entrada = int(input("Ingrese un número entero distinto de cero: "))
    while entrada== 0: 
        print("El número no puede ser cero.")
        entrada = int(input("Ingrese un número entero distinto de cero: "))
    vector_lista.append(entrada)
print("Números compuestos en el vector:")
compuestos_entrada= [numeros for numeros in 
            vector_lista if existe_compuesto(numeros)]

if compuestos_entrada:
    print([numeros for numeros in 
        vector_lista if existe_compuesto(numeros)]) 
else:
    print("No hay números compuestos en el vector.") 

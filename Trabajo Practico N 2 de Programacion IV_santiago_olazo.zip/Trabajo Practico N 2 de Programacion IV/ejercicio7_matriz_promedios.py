M= int(input("Ingrese la cantidad de filas: "))
N= int(input("Ingrese la cantidad de columnas: "))

matriz= []
for f in range(M):
    fila= []
    for c in range(N):
        numero= float(input(f"Ingrese el valor para la posición [{f+1},{c+1}]: "))
        fila.append(numero) 
    matriz.append(fila)  

print("Matriz ingresada:")
for fila in matriz:
    print(fila)

promedios_de_filas= []
for fila in matriz:
    promedio_de_fila = sum(fila) / N 
    promedios_de_filas.append(promedio_de_fila)

promedios_de_columnas= []
for c in range(N):
    suma_columna = sum(matriz[f][c] for f in range(M))  
    promedio_de_columna = suma_columna / M
    promedios_de_columnas.append(promedio_de_columna)

print("Promedios de cada fila:")
for f, promedio in enumerate(promedios_de_filas, start=1):
    print(f"Fila {f}: {promedio:.2f}")

print("Promedios de cada columna:")
for c, promedio in enumerate(promedios_de_columnas, start=1):
    print(f"Columna {c}: {promedio:.2f}")

def contar_los_digitos(): 
    numeros_enteros= input("Ingrese un número entero: ")
    if numeros_enteros.isdigit() or (numeros_enteros.startswith('-') and numeros_enteros[1:].isdigit()): 
        cantidad_numeros= len(numeros_enteros.lstrip('-'))  
        print(f"El número tiene la cantidad de {cantidad_numeros} dígitos")
    else:
        print("Incorrecto, ingrese un número entero válido")
contar_los_digitos()
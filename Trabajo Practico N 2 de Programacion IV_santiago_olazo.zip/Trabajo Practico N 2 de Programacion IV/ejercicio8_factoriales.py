def calcular_factorial(n):
    if n < 0:
        return None 
    if n == 0 or n == 1:
        return 1
    factorial = 1
    for i in range(2, n + 1):
        factorial *= i
        if factorial > 1e6:  
            return factorial
    return factorial

def procesar_matriz(M):
    matriz = []

    print(f"Ingrese la matriz de tamaño {M}x{M}, fila por fila separada por espacios:")
    for i in range(M):
        while True:
            try:
                fila = list(map(int, input(f"Fila {i+1}: ").split()))
                if len(fila) != M:
                    print(f"Error: Debes ingresar exactamente {M} números.")
                    continue
                matriz.append(fila)
                break
            except ValueError:
                print("Error: Ingresa solo números enteros.")

    suma_diagonal = sum(matriz[i][i] for i in range(M))

    vector_resultado = []
    for i in range(M):
        for j in range(M):
            num = matriz[i][j]
            if num < 0:
                continue  
            factorial = calcular_factorial(num)
            if factorial is not None and factorial >= suma_diagonal:
                if num not in vector_resultado:  
                    vector_resultado.append(num)

    print("Matriz original:")
    for fila in matriz:
        print(fila)
    
    print(f"Suma de la diagonal principal: {suma_diagonal}")
    print(f"Vector con elementos cuyo factorial es mayor o igual a la suma de la diagonal: {vector_resultado}")

while True:
    try:
        M = int(input("Ingrese el tamaño de la matriz M (MxM): "))
        if M <= 0:
            print("Error: El tamaño de la matriz debe ser un número positivo.")
            continue
        break
    except ValueError:
        print("Error: Ingresa un número entero positivo.")

procesar_matriz(M)
